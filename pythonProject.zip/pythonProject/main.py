from flask import Flask, render_template, request, redirect, session, url_for, flash
from flask_sqlalchemy import SQLAlchemy
import pymysql
pymysql.install_as_MySQLdb()
import pickle

app= Flask(__name__, template_folder='templates')
model = pickle.load(open('model.pkl', 'rb'))

ENV = 'dev'
app.secret_key = 'secretKey'
if ENV == 'dev':
    app.debug =True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:Sana1234@localhost:3306/loan_db'
else:
    app.debug = False
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:Sana1234@localhost:3306/loan_db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
app.app_context().push()

class User(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    username = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))

    def __str__(self):
        return f"{self.username} has been registered successfully"

db.create_all()

@app.route('/', methods=['GET'])
def homepage():
    return render_template('home.html')

@app.route('/register', methods= ['GET','POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')

    elif request.method == 'POST':
        valid_username = \
            User.query.filter(User.username == request.form.get('username')).first()
        if valid_username:
            flash('Username already exists', 'error')
            return redirect(url_for('register'))
        else:
            new_credential = User(username = request.form.get('username'), password=request.form.get('password'))

            db.session.add(new_credential)
            db.session.commit()

            flash("user registered successfully", 'success')
            return render_template('home.html', message='user registered successfully')

    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method =='GET':
        return render_template('login.html')

    elif request.method == 'POST':

        valid_credentials = \
            User.query.filter_by(username=request.form.get('username'), password=request.form.get('password')).first()

        if valid_credentials is not None:
            session['logged_in'] = True
            session['username'] = request.form.get('username')
            strn = url_for("details")
            print(strn)
            return redirect(strn)
        else:
            flash('Invalid Username or Password')
            return redirect(url_for('login'))

@app.route('/details', methods=['GET'])
def details():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    else:
        return render_template('predict.html')

@app.route('/predict', methods=['GET','POST'])
def predict():

    if not session.get('logged_in'):
        return redirect(url_for('login'))

    elif request.method == 'POST':

        gender = request.form['gender']
        married = request.form['married']
        dependents = int(request.form['dependents'])
        education = request.form['education']
        self_employed = request.form['self_employed']
        applicantincome = int(request.form['applicantincome'])
        coapplicantincome = int(request.form['coapplicantincome'])
        loanamout = int(request.form['loanamout'])
        loanamountterm = int(request.form['loanamountterm'])
        credit_history = request.form['credit_history']
        property_area = request.form['property_area']


        prediction = model.predict(
            [[gender, married, dependents, education, self_employed, applicantincome, coapplicantincome, loanamout, loanamountterm, credit_history,property_area]])

        output = round(prediction[0], 1)

        if output>= 0.5:
            return render_template('predict.html', prediction_text="Congratulations!!!... You are eligible for the loan".format(output))
        else:
            return render_template('predict.html',
                                   prediction_text="OOPs,,, Sorry!!!... You are not eligible for the loan".format(output))

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run()
